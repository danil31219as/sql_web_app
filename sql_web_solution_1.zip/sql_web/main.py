from flask import Flask
from data import db_session
from flask_login import LoginManager, login_user, logout_user, login_required
from data.users import User
from flask import render_template
from data.login_form import LoginForm
from flask import redirect

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
login_manager = LoginManager()
login_manager.init_app(app)
main_user = 'admin'


def main():
    db_session.global_init("db/blogs.sqlite")


@login_manager.user_loader
def load_user(user_id):
    session = db_session.create_session()
    return session.query(User).get(user_id)


@app.route('/')
def start():
    return render_template('base.html', title='Личный кабинет', text=main_user)


@app.route('/login', methods=['GET', 'POST'])
def login():
    global main_user
    form = LoginForm()
    if form.validate_on_submit():
        session = db_session.create_session()
        user = session.query(User).filter(
            User.email == form.email.data).first()
        if user and user.hashed_password == form.password.data:
            login_user(user, remember=form.remember_me.data)
            main_user = user.name
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form,
                           text='Наше приложение')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


if __name__ == '__main__':
    main()
    app.run(port=8080, host='127.0.0.1')
